import streamlit as st
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
import cv2
from PIL import Image
import os
from auth import login_page, register_page, logout



# Handle Authentication
query_params = st.experimental_get_query_params()
current_page = query_params.get("page", ["login"])[0]
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = ""
if not st.session_state.logged_in:
    if current_page == "register":
        register_page()
    else:
        login_page()
    st.stop()

# Logout button
st.sidebar.button("Logout", on_click=logout)

# Set background image function
def set_background(image_url):
    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("{image_url}");
            background-size: cover;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

# Set background for the main page
set_background("https://t4.ftcdn.net/jpg/03/34/01/99/360_F_334019977_A4Oooxbf0NfWpOM21Jz2OHgF4iP9mu4n.jpg")


# Load the trained model
MODEL_PATH = "effnet.h5"
model = load_model(MODEL_PATH, compile=False)


# Define blood type labels
labels = ['A+', 'A-', 'AB+', 'AB-', 'B+', 'B-', 'O+', 'O-']

# Recommendations based on blood groups
def get_recommendations(blood_group):
    recommendations = {
        "A+": {"Fruits": ["Berries", "Apples"], "Vegetables": ["Spinach", "Carrots"], "Exercise": ["Yoga", "Meditation"]},
        "A-": {"Fruits": ["Oranges", "Pineapple"], "Vegetables": ["Celery", "Zucchini"], "Exercise": ["Walking", "Tai Chi"]},
        "B+": {"Fruits": ["Bananas", "Papaya"], "Vegetables": ["Broccoli", "Eggplant"], "Exercise": ["Swimming", "Cycling"]},
        "B-": {"Fruits": ["Grapes", "Pineapple"], "Vegetables": ["Cabbage", "Beets"], "Exercise": ["Hiking", "Dancing"]},
        "AB+": {"Fruits": ["Figs", "Watermelon"], "Vegetables": ["Cauliflower", "Kale"], "Exercise": ["Light jogging", "Yoga"]},
        "AB-": {"Fruits": ["Cherries", "Kiwi"], "Vegetables": ["Cucumber", "Spinach"], "Exercise": ["Stretching", "Walking"]},
        "O+": {"Fruits": ["Mango", "Bananas"], "Vegetables": ["Broccoli", "Peppers"], "Exercise": ["Running", "Weightlifting"]},
        "O-": {"Fruits": ["Plums", "Avocado"], "Vegetables": ["Kale", "Tomatoes"], "Exercise": ["Aerobics", "HIIT"]}
    }
    return recommendations.get(blood_group, {"Fruits": [], "Vegetables": [], "Exercise": []})

# Function to preprocess image
def preprocess_image(image):
    image = image.convert('RGB')  # Ensure RGB format
    image = np.array(image)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)  # Convert to OpenCV format
    image = cv2.resize(image, (150, 150))
    image = np.expand_dims(image, axis=0)  # Reshape for model input
    return image

# Streamlit UI
st.title("Blood Type Classification using EfficientNet")
st.write("Upload an image to classify the blood type.")

uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg", "bmp"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded Image', use_column_width=True)
    
    # Preprocess and predict
    processed_image = preprocess_image(image)
    prediction = model.predict(processed_image)
    predicted_class = np.argmax(prediction)
    blood_type = labels[predicted_class]
    
    # Display results
    st.subheader(f"Predicted Blood Type: {blood_type}")
    
    # Show recommendations
    rec = get_recommendations(blood_type)
    st.subheader("Health Recommendations:")
    st.write(f"**Fruits:** {', '.join(rec['Fruits'])}")
    st.write(f"**Vegetables:** {', '.join(rec['Vegetables'])}")
    st.write(f"**Exercise:** {', '.join(rec['Exercise'])}")
