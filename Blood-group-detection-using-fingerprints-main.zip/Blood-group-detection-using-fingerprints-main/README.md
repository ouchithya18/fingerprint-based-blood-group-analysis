# Blood-group-detection-using-fingerprints
To develop a deep learning-based system that can automatically detect a person’s blood group using a fingerprint image and provide personalized nutrient and health recommendations  all through with a user-friendly Streamlit web interface.
